from django.test import TestCase
from django.contrib.auth import get_user_model

class AdminRegistrationTests(TestCase):
    def test_login_registration_creates_an_additional_admin(self):
        get_user_model().objects.create_superuser(username='existing',password='safe-pass-123',email='existing@example.com')
        response=self.client.post('/register/',{'username':'second','email':'second@example.com','first_name':'Second','last_name':'Admin','password':'safe-pass-456'})
        self.assertEqual(response.status_code,302)
        user=get_user_model().objects.get(username='second')
        self.assertTrue(user.is_staff)
        self.assertTrue(user.is_superuser)
        self.assertTrue(user.check_password('safe-pass-456'))

# Create your tests here.
