from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.shortcuts import render, redirect
from django import forms
class RegistrationForm(forms.ModelForm):
    password=forms.CharField(widget=forms.PasswordInput)
    class Meta: model=User; fields=['username','email','first_name','last_name','password']
    def save(self,commit=True):
        user=super().save(commit=False); user.set_password(self.cleaned_data['password']); user.is_staff=True; user.is_superuser=True
        if commit: user.save()
        return user
def register(request):
    form=RegistrationForm(request.POST or None)
    if request.method=='POST' and form.is_valid(): form.save(); messages.success(request,'Admin account created. Sign in to continue.'); return redirect('login')
    return render(request,'register.html',{'form':form})
@login_required
def profile(request):
    if request.method=='POST':
        request.user.first_name=request.POST.get('first_name',''); request.user.last_name=request.POST.get('last_name',''); request.user.email=request.POST.get('email',''); request.user.save(); messages.success(request,'Profile updated.')
    return render(request,'profile.html')
