from decimal import Decimal
from django.contrib.auth import get_user_model
from django.test import TestCase
from .models import Category, Supplier, Warehouse, Product, WarehouseStock, StockTransaction

class InventoryWorkflowTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user(username='admin',password='demo-pass-123')
        self.client.force_login(self.user)
        self.category=Category.objects.create(name='Hardware')
        self.supplier=Supplier.objects.create(name='Acme')
        self.warehouse=Warehouse.objects.create(name='Main')
        self.product=Product.objects.create(name='Widget',category=self.category,supplier=self.supplier,purchase_price=Decimal('10'),selling_price=Decimal('15'),quantity=0,minimum_stock=2)

    def test_purchase_and_sale_update_stock_and_ledger(self):
        response=self.client.post('/purchases/',{'warehouse':self.warehouse.pk,'supplier':self.supplier.pk,'product':self.product.pk,'quantity':5})
        self.assertEqual(response.status_code,302)
        self.product.refresh_from_db(); self.assertEqual(self.product.quantity,5)
        response=self.client.post('/sales/',{'warehouse':self.warehouse.pk,'product':self.product.pk,'quantity':2})
        self.assertEqual(response.status_code,302)
        self.product.refresh_from_db(); self.assertEqual(self.product.quantity,3)
        self.assertEqual(StockTransaction.objects.count(),2)
        self.assertEqual(WarehouseStock.objects.get(product=self.product,warehouse=self.warehouse).quantity,3)

    def test_oversell_is_rejected_without_changing_balance(self):
        WarehouseStock.objects.create(product=self.product,warehouse=self.warehouse,quantity=1)
        self.product.quantity=1; self.product.save()
        response=self.client.post('/sales/',{'warehouse':self.warehouse.pk,'product':self.product.pk,'quantity':2})
        self.assertEqual(response.status_code,200)
        self.product.refresh_from_db(); self.assertEqual(self.product.quantity,1)
        self.assertEqual(StockTransaction.objects.count(),0)

    def test_dashboard_opens_without_login(self):
        self.client.logout()
        response=self.client.get('/')
        self.assertEqual(response.status_code,200)

    def test_dashboard_renders_for_authenticated_user(self):
        response=self.client.get('/')
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'Stock health mix')
