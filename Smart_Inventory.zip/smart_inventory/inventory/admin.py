from django.contrib import admin
from .models import Category, Supplier, Warehouse, Product, WarehouseStock, Purchase, PurchaseItem, Sale, SaleItem, StockTransaction
admin.site.register([Category,Supplier,Warehouse,Product,WarehouseStock,Purchase,PurchaseItem,Sale,SaleItem,StockTransaction])
