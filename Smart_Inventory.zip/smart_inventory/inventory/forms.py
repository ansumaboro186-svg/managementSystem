from django import forms
from .models import Product, Category, Supplier, Warehouse

class ProductForm(forms.ModelForm):
    class Meta: model=Product; fields=['name','category','supplier','description','purchase_price','selling_price','quantity','minimum_stock']
class CategoryForm(forms.ModelForm):
    class Meta: model=Category; fields=['name','description']
class SupplierForm(forms.ModelForm):
    class Meta: model=Supplier; fields=['name','phone','email','address','city','district','pin_code']
class WarehouseForm(forms.ModelForm):
    class Meta: model=Warehouse; fields=['name','address','city']
class StockForm(forms.Form):
    product=forms.ModelChoiceField(queryset=Product.objects.all())
    warehouse=forms.ModelChoiceField(queryset=Warehouse.objects.all())
    kind=forms.ChoiceField(choices=[('IN','Stock in'),('OUT','Stock out'),('ADJUST','Set quantity')])
    quantity=forms.IntegerField(min_value=0)
    note=forms.CharField(required=False)
class OrderForm(forms.Form):
    warehouse=forms.ModelChoiceField(queryset=Warehouse.objects.all())
    supplier=forms.ModelChoiceField(queryset=Supplier.objects.all(),required=False)
    product=forms.ModelChoiceField(queryset=Product.objects.all())
    quantity=forms.IntegerField(min_value=1)
class TransferForm(forms.Form):
    product=forms.ModelChoiceField(queryset=Product.objects.all())
    source=forms.ModelChoiceField(queryset=Warehouse.objects.all())
    destination=forms.ModelChoiceField(queryset=Warehouse.objects.all())
    quantity=forms.IntegerField(min_value=1)
    def clean(self):
        data=super().clean()
        if data.get('source')==data.get('destination'): raise forms.ValidationError('Choose two different warehouses.')
        return data
