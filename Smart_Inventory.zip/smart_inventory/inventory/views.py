import csv
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models.deletion import ProtectedError
from django.db.models import Sum, F, Count
from django.db.models.functions import TruncDate
from datetime import timedelta
from django.utils import timezone
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from .models import Product, Supplier, Category, Warehouse, WarehouseStock, StockTransaction, Purchase, PurchaseItem, Sale, SaleItem
from .forms import ProductForm, SupplierForm, CategoryForm, WarehouseForm, StockForm, OrderForm, TransferForm

def dashboard(request):
    products=Product.objects.select_related('category','supplier')
    low=products.filter(quantity__lte=F('minimum_stock'))
    today=timezone.localdate(); days=[today-timedelta(days=i) for i in range(6,-1,-1)]
    movement_counts={row['day']:row['n'] for row in StockTransaction.objects.filter(created_at__date__gte=days[0]).annotate(day=TruncDate('created_at')).values('day').annotate(n=Count('id'))}
    recent=StockTransaction.objects.select_related('product','warehouse')[:8]
    return render(request,'dashboard.html',{'product_count':products.count(),'supplier_count':Supplier.objects.count(),'category_count':Category.objects.count(),'stock_total':products.aggregate(n=Sum('quantity'))['n'] or 0,'low':low,'out_count':products.filter(quantity=0).count(),'value':sum((p.quantity*p.purchase_price for p in products),start=0),'transactions':recent,'rows':[],'categories':Category.objects.annotate(n=Count('products')),'in_stock_count':products.filter(quantity__gt=F('minimum_stock')).count(),'low_count':low.exclude(quantity=0).count(),'chart_days':days,'movement_counts':[movement_counts.get(day,0) for day in days]})

@login_required
def listing(request, model, form, title):
    rows=model.objects.all(); q=request.GET.get('q','').strip()
    if q and hasattr(model,'name'): rows=rows.filter(name__icontains=q)
    edit=get_object_or_404(model,pk=request.GET.get('edit')) if request.GET.get('edit') else None
    if request.method=='POST':
        instance=get_object_or_404(model,pk=request.POST.get('pk')) if request.POST.get('pk') else None
        f=form(request.POST,instance=instance)
        if f.is_valid(): f.save(); messages.success(request,f'{title} saved.'); return redirect(request.path)
    else: f=form(instance=edit)
    kind={'Products':'product','Categories':'category','Suppliers':'supplier','Warehouses':'warehouse'}[title]
    return render(request,'listing.html',{'rows':rows,'form':f,'title':title,'edit':edit,'q':q,'kind':kind})

@login_required
def products(request): return listing(request,Product,ProductForm,'Products')
@login_required
def categories(request): return listing(request,Category,CategoryForm,'Categories')
@login_required
def suppliers(request): return listing(request,Supplier,SupplierForm,'Suppliers')
@login_required
def warehouses(request): return listing(request,Warehouse,WarehouseForm,'Warehouses')

@login_required
def delete_row(request, kind, pk):
    model={'product':Product,'category':Category,'supplier':Supplier,'warehouse':Warehouse}.get(kind)
    if model and request.method=='POST':
        try: get_object_or_404(model,pk=pk).delete(); messages.success(request,'Record deleted.')
        except ProtectedError: messages.error(request,'This record is in use and cannot be deleted.')
    return redirect(request.META.get('HTTP_REFERER','dashboard'))

@login_required
def stock(request):
    form=StockForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data; p=d['product']; w=d['warehouse']; qty=d['quantity']; kind=d['kind']
        row,created=WarehouseStock.objects.get_or_create(product=p,warehouse=w); current=row.quantity
        if kind=='OUT' and qty>current: form.add_error('quantity','Insufficient stock at this warehouse.')
        else:
            with transaction.atomic():
                new=qty if kind=='ADJUST' else current+(qty if kind=='IN' else -qty)
                delta=abs(new-current); row.quantity=new; row.save(); p.quantity=max(0,p.quantity+(new-current)); p.save(update_fields=['quantity'])
                StockTransaction.objects.create(product=p,warehouse=w,kind=kind,quantity=delta,note=d['note'],created_by=request.user)
            messages.success(request,'Stock updated and transaction recorded.'); return redirect('stock')
    return render(request,'stock.html',{'form':form,'rows':StockTransaction.objects.select_related('product','warehouse')[:100]})

@login_required
def export_products(request):
    response=HttpResponse(content_type='text/csv'); response['Content-Disposition']='attachment; filename="inventory.csv"'
    writer=csv.writer(response); writer.writerow(['Product','Category','Supplier','Quantity','Min stock','Purchase price','Selling price'])
    for p in Product.objects.select_related('category','supplier'): writer.writerow([p.name,p.category,p.supplier,p.quantity,p.minimum_stock,p.purchase_price,p.selling_price])
    return response

@login_required
def export_pdf(request):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import landscape, letter
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
    from reportlab.lib.styles import getSampleStyleSheet
    response=HttpResponse(content_type='application/pdf'); response['Content-Disposition']='attachment; filename="inventory-report.pdf"'
    doc=SimpleDocTemplate(response,pagesize=landscape(letter)); data=[['Product','Category','Supplier','Quantity','Minimum','Purchase price','Selling price']]
    for p in Product.objects.select_related('category','supplier'): data.append([p.name,p.category.name,p.supplier.name,str(p.quantity),str(p.minimum_stock),str(p.purchase_price),str(p.selling_price)])
    table=Table(data,repeatRows=1); table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#101d3a')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#dce2ef')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f3f6fb')]),('PADDING',(0,0),(-1,-1),7)]))
    doc.build([Paragraph('Inventory valuation and stock report',getSampleStyleSheet()['Title']),table]); return response

@login_required
def movement_report(request): return render(request,'stock.html',{'rows':StockTransaction.objects.select_related('product','warehouse')[:500],'report_only':True})

@login_required
def transfer(request):
    form=TransferForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data; p=d['product']; src=d['source']; dst=d['destination']; qty=d['quantity']
        source,_=WarehouseStock.objects.get_or_create(product=p,warehouse=src); dest,_=WarehouseStock.objects.get_or_create(product=p,warehouse=dst)
        if source.quantity<qty: form.add_error('quantity','Insufficient stock in the source warehouse.')
        else:
            with transaction.atomic():
                source.quantity-=qty; dest.quantity+=qty; source.save(); dest.save()
                StockTransaction.objects.create(product=p,warehouse=src,kind='OUT',quantity=qty,note=f'Transferred to {dst.name}',created_by=request.user)
                StockTransaction.objects.create(product=p,warehouse=dst,kind='IN',quantity=qty,note=f'Transferred from {src.name}',created_by=request.user)
            messages.success(request,'Warehouse transfer completed.'); return redirect('transfer')
    return render(request,'transfer.html',{'form':form,'rows':StockTransaction.objects.filter(kind__in=['IN','OUT']).select_related('product','warehouse')[:100]})

@login_required
def orders(request, order_type):
    purchase=order_type=='purchase'; form=OrderForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        d=form.cleaned_data; product=d['product']; warehouse=d['warehouse']; qty=d['quantity']
        if not purchase and (product.quantity<qty or (WarehouseStock.objects.filter(product=product,warehouse=warehouse).first() or WarehouseStock(quantity=0)).quantity<qty):
            form.add_error('quantity','Insufficient stock available for this sale.')
        elif purchase and not d['supplier']:
            form.add_error('supplier','Choose a supplier for this purchase.')
        else:
            with transaction.atomic():
                row,_=WarehouseStock.objects.get_or_create(product=product,warehouse=warehouse)
                if purchase:
                    order=Purchase.objects.create(supplier=d['supplier'],warehouse=warehouse,created_by=request.user)
                    PurchaseItem.objects.create(purchase=order,product=product,quantity=qty,unit_price=product.purchase_price)
                    row.quantity+=qty; product.quantity+=qty; kind='IN'; price=product.purchase_price
                else:
                    order=Sale.objects.create(warehouse=warehouse,created_by=request.user)
                    SaleItem.objects.create(sale=order,product=product,quantity=qty,unit_price=product.selling_price)
                    row.quantity-=qty; product.quantity-=qty; kind='OUT'; price=product.selling_price
                row.save(); product.save(update_fields=['quantity'])
                StockTransaction.objects.create(product=product,warehouse=warehouse,kind=kind,quantity=qty,note=f'{"Purchase" if purchase else "Sale"} #{order.pk} total {price*qty}',created_by=request.user)
            messages.success(request,f'{"Purchase" if purchase else "Sale"} recorded. Total: ₹{price*qty:.2f}'); return redirect('purchase' if purchase else 'sale')
    orders=Purchase.objects.prefetch_related('items__product').order_by('-created_at') if purchase else Sale.objects.prefetch_related('items__product').order_by('-created_at')
    return render(request,'orders.html',{'form':form,'purchase':purchase,'orders':orders})
