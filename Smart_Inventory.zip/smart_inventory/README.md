# Smart Inventory and Warehouse Management System

A Django and SQLite academic project for inventory, warehouse stock, purchases, sales, and movement auditing.

## Run locally

From this directory in PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000/ to go straight to the dashboard. Catalog and stock management pages require sign-in. Django admin is available at `/admin/`. The login page links to public admin registration, which can create additional superuser accounts for local project demonstrations. Do not expose this registration route on a public deployment. Password reset is exposed at `/password-reset/`; configure `MAILERS` and SMTP settings for email delivery (console output in development).

## Modules

- `accounts`: Django session login, logout, profile editing, account registration, and password reset.
- `products`: product CRUD through inventory forms and views.
- `suppliers`: supplier directory and CRUD.
- `warehouses`: warehouse directory and stock location records.
- `inventory`: category/product/warehouse stock and append-only movement records.
- `purchases`: purchase headers/items and inbound stock updates.
- `sales`: sale headers/items, stock checks, and outbound updates.
- `reports`: CSV inventory export and movement history screens.

Domain models are centralized in `inventory/models.py` so the relationships and transaction updates can be audited in one place. The other Django apps provide the requested module boundaries and can be extended independently.

## Data integrity and behavior

- Django hashes passwords and protects views with authenticated sessions.
- Product category and supplier references are protected from accidental deletion.
- Warehouse/product stock rows have a unique constraint.
- Stock and order changes are wrapped in database transactions, and every purchase, sale, or manual adjustment writes a `StockTransaction`.
- Sales reject quantities above the selected warehouse balance.
- Low stock means quantity less than or equal to the configured minimum.

## Academic documentation

See `docs/SRS.md`, `docs/diagrams.md`, and `docs/test-cases.md` for scope, requirements, diagrams, and a manual verification checklist. Inventory exports are available as CSV (`/reports/inventory.csv`) and PDF (`/reports/inventory.pdf`). Warehouse transfers use paired inbound and outbound ledger rows.

## Suggested viva walkthrough

1. Create Category, Supplier, Product, and Warehouse records.
2. Record a purchase to increase product and warehouse balances.
3. Record a sale and show the insufficient-stock validation.
4. Record a manual stock movement and inspect the audit history.
5. Show dashboard low-stock indicators and download the inventory CSV.
