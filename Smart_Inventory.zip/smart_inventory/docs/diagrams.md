# System design diagrams

## Use case diagram
```mermaid
flowchart LR
  Admin([Administrator]) --> Auth[Sign in / manage profile]
  Admin --> Catalog[Manage products, categories, suppliers]
  Admin --> WH[Manage warehouses]
  Admin --> Stock[Record and review stock movements]
  Admin --> Buy[Record purchases]
  Admin --> Sell[Record sales]
  Admin --> Dash[Review dashboard and alerts]
  Admin --> Export[Export inventory CSV]
```

## DFD level 0
```mermaid
flowchart LR
  A[Administrator] -->|catalog, stock, orders| S((Inventory Management System))
  S -->|dashboard, alerts, reports| A
  S <--> DB[(SQLite database)]
```

## ER diagram
```mermaid
erDiagram
  CATEGORY ||--o{ PRODUCT : groups
  SUPPLIER ||--o{ PRODUCT : supplies
  PRODUCT ||--o{ WAREHOUSE_STOCK : stored_as
  WAREHOUSE ||--o{ WAREHOUSE_STOCK : contains
  SUPPLIER ||--o{ PURCHASE : receives
  WAREHOUSE ||--o{ PURCHASE : delivered_to
  PURCHASE ||--|{ PURCHASE_ITEM : contains
  PRODUCT ||--o{ PURCHASE_ITEM : bought
  WAREHOUSE ||--o{ SALE : ships
  SALE ||--|{ SALE_ITEM : contains
  PRODUCT ||--o{ SALE_ITEM : sold
  PRODUCT ||--o{ STOCK_TRANSACTION : moves
  WAREHOUSE ||--o{ STOCK_TRANSACTION : location
```

## System architecture
```mermaid
flowchart TB
  Browser[Chrome / HTML Bootstrap JavaScript] --> URL[Django URL routing]
  URL --> Views[Authenticated Django views and forms]
  Views --> ORM[Django ORM and transaction.atomic]
  ORM --> DB[(SQLite)]
  Views --> Charts[Chart.js dashboard]
  Views --> CSV[CSV report response]
```
