# Software Requirements Specification

## Purpose
Provide a local, single-organization inventory tool suitable for demonstration and learning Django ORM, authentication, relational design, and stock workflows.

## Scope and actors
An authenticated administrator maintains products, categories, suppliers, warehouses, stock, purchases, and sales. Anonymous visitors can reach login and account registration. The system uses SQLite locally and a browser UI served by Django.

## Functional requirements
1. Authenticate users with Django's hashed-password and session facilities; support logout, profile update, registration, and password-reset flow.
2. Create, read, update, search, and delete products, categories, suppliers, and warehouses.
3. Maintain one quantity row per product and warehouse; record stock in, stock out, and absolute adjustment.
4. Record purchase and sale headers with an item and unit price; update balances atomically and log a stock transaction.
5. Show summary counts, inventory valuation at purchase cost, low/out-of-stock products, category chart, and recent transactions.
6. Export an inventory CSV and view transaction history.

## Non-functional requirements
- Browser-responsive Bootstrap layout, server-side validation, CSRF protection, authenticated business views, ORM queries, foreign-key integrity, and atomic order/movement writes.
- SQLite is appropriate for local academic demonstration; production deployment would require hardened settings and a production database.

## Data model summary
User (Django auth) creates Purchase, Sale, and StockTransaction records. Category and Supplier each relate one-to-many to Product. Product and Warehouse relate many-to-many through WarehouseStock. Purchase has supplier and warehouse; PurchaseItem connects products to a purchase. SaleItem connects products to a sale. Transactions reference product, warehouse, and user.

## Assumptions / limits
The order form currently records one product per purchase/sale header. Transfers can be represented as paired stock out/in adjustments; a dedicated transfer workflow and PDF exports are extension points. Registration is open in this local academic build. Configure SMTP for real password reset delivery.
