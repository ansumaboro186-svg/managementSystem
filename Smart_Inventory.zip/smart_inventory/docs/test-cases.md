# Manual test cases

Use a fresh local database and create one category, supplier, warehouse, and product first.

| ID | Scenario | Steps | Expected result |
|---|---|---|---|
| TC-01 | Authentication | Sign in with a valid account; then sign out | Dashboard is protected and session ends on logout |
| TC-02 | Product validation | Submit product with missing required fields | Form displays validation errors; no row is saved |
| TC-03 | Search | Search products by partial name | Matching products appear |
| TC-04 | Purchase | Buy 10 units into a warehouse | Product and warehouse stock rise by 10; purchase and IN transaction exist |
| TC-05 | Sale | Sell 3 units when warehouse has 10 | Product and warehouse stock fall to 7; sale and OUT transaction exist |
| TC-06 | Oversell | Sell more units than selected warehouse has | Error appears and balances remain unchanged |
| TC-07 | Adjustment | Set warehouse quantity to a new absolute amount | Product total is adjusted by the difference; transaction is recorded |
| TC-08 | Low stock | Lower quantity to minimum or below | Dashboard lists product as low stock |
| TC-09 | CSV | Open Inventory CSV in navigation | Download contains current product, quantity, price, supplier, and category values |
| TC-10 | Delete protection | Delete a supplier referenced by a product | Database protects the reference and displays an error rather than orphaning a product |
