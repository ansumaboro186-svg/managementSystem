"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from inventory import views
from accounts import views as account_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.dashboard, name='dashboard'),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('password-reset/', auth_views.PasswordResetView.as_view(template_name='password_reset.html'), name='password_reset'),
    path('register/', account_views.register, name='register'), path('profile/', account_views.profile, name='profile'),
    path('products/', views.products, name='products'), path('categories/', views.categories, name='categories'),
    path('suppliers/', views.suppliers, name='suppliers'), path('warehouses/', views.warehouses, name='warehouses'),
    path('stock/', views.stock, name='stock'), path('reports/inventory.csv', views.export_products, name='export_products'),
    path('transfer/', views.transfer, name='transfer'),
    path('reports/inventory.pdf', views.export_pdf, name='export_pdf'),
    path('purchases/', views.orders, {'order_type':'purchase'}, name='purchase'), path('sales/', views.orders, {'order_type':'sale'}, name='sale'),
    path('reports/movements/', views.movement_report, name='movement_report'),
    path('delete/<str:kind>/<int:pk>/', views.delete_row, name='delete_row'),
]
